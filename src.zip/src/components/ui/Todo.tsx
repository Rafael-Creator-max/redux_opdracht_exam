// import React from "react";
// import { Badge } from "@/components/ui/badge";
// import {
//   useUpdateTodoMutation,
//   useDeleteTodoMutation,
// } from "../../api/todoApi";

// export interface TodoProps {
//   id: string;
//   text: string;
//   completed: boolean;
//   category?: string;
//   categories: { name: string; color: string }[];
//   description?: string;
// }

// const Todo: React.FC<TodoProps> = ({
//   id,
//   text,
//   completed,
//   category,
//   categories,
//   description,
// }) => {
//   const [updateTodo] = useUpdateTodoMutation();
//   const [deleteTodo] = useDeleteTodoMutation();

//   //  Ensure category is always a valid object
//   const matchedCategory = categories.find((cat) => cat.name === category) || {
//     name: "Uncategorized",
//     color: "gray",
//   };

//   return (
//     <div className="flex items-center justify-between p-3 bg-white shadow rounded-md mb-2">
//       {/* Checkbox for toggling completed */}
//       <input
//         type="checkbox"
//         checked={completed}
//         onChange={() =>
//           updateTodo({
//             id,
//             text,
//             category,
//             description,
//             completed: !completed,
//           })
//         }
//         className="cursor-pointer"
//       />

//       {/*  Todo Text */}
//       <span
//         className={`flex-grow ${
//           completed ? "line-through text-gray-600" : "text-black font-medium"
//         }`}
//       >
//         {text || "Untitled Todo"}
//       </span>

//       {/*  Category Badge  */}
//       <Badge style={{ backgroundColor: matchedCategory.color }}>
//         {matchedCategory.name}
//       </Badge>

//       {/*  Delete Button */}
//       <button
//         onClick={() => deleteTodo(id)}
//         className="p-1 text-red-500 hover:text-red-700"
//       >
//         ❌
//       </button>
//     </div>
//   );
// };

// export default Todo;
import React from "react";
import { Badge } from "@/components/ui/badge";
import {
  useUpdateTodoMutation,
  useDeleteTodoMutation,
} from "../../api/todoApi";

export interface TodoProps {
  id: string;
  text: string;
  completed: boolean;
  category?: string;
  categories: { name: string; color: string }[];
  description?: string;
  onDelete: (id: string) => void;
}

const Todo: React.FC<TodoProps> = ({
  id,
  text,
  completed,
  category,
  categories,
  description,
}) => {
  const [updateTodo] = useUpdateTodoMutation();
  const [deleteTodo] = useDeleteTodoMutation();

  // ✅ Ensure category is always a valid object
  const matchedCategory = categories.find((cat) => cat.name === category) || {
    name: "Uncategorized",
    color: "gray",
  };

  return (
    <div className="flex items-center justify-between p-3 bg-white shadow rounded-md mb-2">
      {/* ✅ Checkbox for toggling completed */}
      <input
        type="checkbox"
        checked={completed}
        onChange={() =>
          updateTodo({
            id,
            text,
            category,
            description,
            completed: !completed, // ✅ Only toggle "completed"
          })
        }
        className="cursor-pointer"
      />

      {/* ✅ Todo Text */}
      <span
        className={`flex-grow ${
          completed ? "line-through text-gray-600" : "text-black font-medium"
        }`}
      >
        {text || "Untitled Todo"} {/* ✅ Prevent empty text */}
      </span>

      {/* ✅ Category Badge (Now always has a valid value) */}
      <Badge style={{ backgroundColor: matchedCategory.color }}>
        {matchedCategory.name}
      </Badge>

      {/* ✅ Edit Button */}
      <button className="p-1 text-gray-600 hover:text-gray-800">✏️</button>

      {/* ✅ Delete Button */}
      <button
        onClick={(e) => {
          e.preventDefault();
          deleteTodo(id);
        }}
        className="p-1 text-red-500 hover:text-red-700"
      >
        ❌
      </button>
    </div>
  );
};

export default Todo;
