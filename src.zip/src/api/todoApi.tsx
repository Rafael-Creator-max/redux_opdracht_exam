import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const todoApi = createApi({
  reducerPath: "todoApi",
  baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:3001" }),
  endpoints: (builder) => ({
    getTodos: builder.query({
      query: () => "/todos",
    }),
    getCategories: builder.query({
      // Added getCategories
      query: () => "/categories",
    }),
    addTodo: builder.mutation({
      query: (newTodo) => ({
        url: "/todos",
        method: "POST",
        body: newTodo,
      }),
    }),
    updateTodo: builder.mutation({
      query: ({ id, ...updatedTodo }) => ({
        url: `/todos/${id}`,
        method: "PUT",
        body: updatedTodo,
      }),
    }),
    deleteTodo: builder.mutation({
      query: (id) => ({
        url: `/todos/${id}`,
        method: "DELETE",
      }),
    }),
  }),
});

//  exporting useGetCategoriesQuery along with other queries
export const {
  useGetTodosQuery,
  useGetCategoriesQuery,
  useAddTodoMutation,
  useUpdateTodoMutation,
  useDeleteTodoMutation,
} = todoApi;

export default todoApi;
// import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// export const todoApi = createApi({
//   reducerPath: "todoApi",
//   baseQuery: fetchBaseQuery({ baseUrl: "http://localhost:3001" }),
//   tagTypes: ["Todos", "Categories"], // ✅ Define tag for categories
//   endpoints: (builder) => ({
//     getTodos: builder.query({
//       query: () => "/todos",
//       providesTags: ["Todos"], // ✅ Auto-refresh todos
//     }),
//     getCategories: builder.query({
//       query: () => "/categories", // ✅ Fetch categories from json-server
//       providesTags: ["Categories"], // ✅ Auto-refresh categories
//     }),
//     addTodo: builder.mutation({
//       query: (newTodo) => ({
//         url: "/todos",
//         method: "POST",
//         body: newTodo,
//       }),
//       invalidatesTags: ["Todos"], // ✅ Auto-refresh todo list after adding
//     }),
//     updateTodo: builder.mutation({
//       query: ({ id, text, category, description, completed }) => ({
//         url: `/todos/${id}`,
//         method: "PATCH",
//         body: { id, text, category, description, completed },
//       }),
//       invalidatesTags: ["Todos"], // ✅ Auto-refresh todo list after updating
//     }),
//     deleteTodo: builder.mutation({
//       query: (id) => ({
//         url: `/todos/${id}`,
//         method: "DELETE",
//       }),
//       invalidatesTags: ["Todos"], // ✅ Auto-refresh todo list after deleting
//     }),
//   }),
// });

// export const {
//   useGetTodosQuery,
//   useGetCategoriesQuery, // ✅ Export categories query
//   useAddTodoMutation,
//   useUpdateTodoMutation,
//   useDeleteTodoMutation,
// } = todoApi;

// export default todoApi;
